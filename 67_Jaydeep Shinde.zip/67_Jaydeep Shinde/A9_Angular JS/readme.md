Since I'm directly using the CDN version of AngularJS, you require internet connection to run this project.<br>
Other alternatives are extracting the angularJs min js file for working without internet.
